import ParticleMorphing from "@/components/ParticleMorphing";

export default function Home() {
  return (
    <div className="fixed inset-0 w-screen h-screen overflow-hidden bg-black">
      <ParticleMorphing />
    </div>
  );
}
