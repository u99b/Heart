import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

export default function ParticleMorphing() {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const particlesRef = useRef<THREE.Points | null>(null);
  const [text, setText] = useState('');
  const isMobileRef = useRef(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent));
  
  const particleCountRef = useRef(isMobileRef.current ? 20000 : 40000);
  const targetPositionsRef = useRef<Array<{ x: number; y: number; z: number }>>([]);
  const velocitiesRef = useRef<Array<{ x: number; y: number; z: number }>>([]);
  const mouseRef = useRef(new THREE.Vector2(-1000, -1000));

  const textCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const textCtxRef = useRef<CanvasRenderingContext2D | null>(null);

  useEffect(() => {
    // Initialize text canvas
    const textCanvas = document.createElement('canvas');
    const textCtx = textCanvas.getContext('2d');
    if (!textCtx) return;
    
    textCanvas.width = 800;
    textCanvas.height = 300;
    textCanvasRef.current = textCanvas;
    textCtxRef.current = textCtx;

    // Initialize Three.js scene
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      75,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    camera.position.z = 35;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, precision: 'highp' });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0x000000, 1);
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';

    if (containerRef.current) {
      containerRef.current.appendChild(renderer.domElement);
    }

    sceneRef.current = scene;
    cameraRef.current = camera;
    rendererRef.current = renderer;

    // Create particles
    const geometry = new THREE.BufferGeometry();
    const posArray = new Float32Array(particleCountRef.current * 3);
    const colorArray = new Float32Array(particleCountRef.current * 3);

    for (let i = 0; i < particleCountRef.current; i++) {
      posArray[i * 3] = (Math.random() - 0.5) * 200;
      posArray[i * 3 + 1] = (Math.random() - 0.5) * 200;
      posArray[i * 3 + 2] = (Math.random() - 0.5) * 200;

      velocitiesRef.current.push({ x: 0, y: 0, z: 0 });

      const r = 0.7 + Math.random() * 0.3;
      const g = 0.1 + Math.random() * 0.15;
      const b = 0.3 + Math.random() * 0.25;

      colorArray[i * 3] = r;
      colorArray[i * 3 + 1] = g;
      colorArray[i * 3 + 2] = b;
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(posArray, 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(colorArray, 3));

    const material = new THREE.PointsMaterial({
      size: isMobileRef.current ? 0.15 : 0.12,
      vertexColors: true,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending,
    });

    const particles = new THREE.Points(geometry, material);
    scene.add(particles);
    particlesRef.current = particles;

    // Initialize target positions
    updateTargets('');

    // Event listeners
    const handleMouseMove = (event: MouseEvent) => {
      mouseRef.current.x = (event.clientX / window.innerWidth) * 2 - 1;
      mouseRef.current.y = -(event.clientY / window.innerHeight) * 2 + 1;
    };

    const handleTouchMove = (event: TouchEvent) => {
      if ((event.target as HTMLElement).id !== 'text-input') {
        event.preventDefault();
        const touch = event.touches[0];
        mouseRef.current.x = (touch.clientX / window.innerWidth) * 2 - 1;
        mouseRef.current.y = -(touch.clientY / window.innerHeight) * 2 + 1;
      }
    };

    const handleTouchEnd = () => {
      mouseRef.current.x = -1000;
      mouseRef.current.y = -1000;
    };

    const handleWindowResize = () => {
      const width = window.innerWidth;
      const height = window.innerHeight;

      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
      renderer.domElement.style.width = '100%';
      renderer.domElement.style.height = '100%';
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('touchmove', handleTouchMove, { passive: false });
    window.addEventListener('touchend', handleTouchEnd);
    window.addEventListener('resize', handleWindowResize);

    // Animation loop
    const animate = () => {
      requestAnimationFrame(animate);

      const posAttr = particles.geometry.attributes.position as THREE.BufferAttribute;

      const vector = new THREE.Vector3(mouseRef.current.x, mouseRef.current.y, 0.5);
      vector.unproject(camera);
      const dir = vector.sub(camera.position).normalize();
      const distance = -camera.position.z / dir.z;
      const mPos = camera.position.clone().add(dir.multiplyScalar(distance));

      for (let i = 0; i < particleCountRef.current; i++) {
        let px = posAttr.getX(i);
        let py = posAttr.getY(i);
        let pz = posAttr.getZ(i);

        const target = targetPositionsRef.current[i];

        const dx = px - mPos.x;
        const dy = py - mPos.y;
        const dz = pz - mPos.z;
        const distSq = dx * dx + dy * dy + dz * dz;
        const dist = Math.sqrt(distSq);

        if (dist < 8) {
          const force = (8 - dist) / 8;
          velocitiesRef.current[i].x += (dx / dist) * force * 1.8;
          velocitiesRef.current[i].y += (dy / dist) * force * 1.8;
          velocitiesRef.current[i].z += (dz / dist) * force * 1.8;
        }

        velocitiesRef.current[i].x += (target.x - px) * 0.08;
        velocitiesRef.current[i].y += (target.y - py) * 0.08;
        velocitiesRef.current[i].z += (target.z - pz) * 0.08;

        velocitiesRef.current[i].x *= 0.78;
        velocitiesRef.current[i].y *= 0.78;
        velocitiesRef.current[i].z *= 0.78;

        posAttr.setXYZ(
          i,
          px + velocitiesRef.current[i].x,
          py + velocitiesRef.current[i].y,
          pz + velocitiesRef.current[i].z
        );
      }

      posAttr.needsUpdate = true;

      particles.rotation.y = 0;
      particles.rotation.z = 0;
      particles.rotation.x = 0;

      renderer.render(scene, camera);
    };

    animate();

    // Cleanup
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleTouchEnd);
      window.removeEventListener('resize', handleWindowResize);
      renderer.dispose();
      geometry.dispose();
      material.dispose();
      if (containerRef.current && renderer.domElement.parentNode === containerRef.current) {
        containerRef.current.removeChild(renderer.domElement);
      }
    };
  }, []);

  const getHeartPoint = (t: number, u: number): THREE.Vector3 => {
    const x = 16 * Math.pow(Math.sin(u), 3) * Math.sin(t);
    const y =
      (13 * Math.cos(u) -
        5 * Math.cos(2 * u) -
        2 * Math.cos(3 * u) -
        Math.cos(4 * u)) *
      Math.sin(t);
    const z = 10 * Math.cos(t);
    return new THREE.Vector3(x * 0.75, y * 0.75, z * 0.75);
  };

  const sampleText = (inputText: string): Array<{ x: number; y: number; z: number }> | null => {
    if (!inputText || inputText.trim() === '') return null;

    const ctx = textCtxRef.current;
    const canvas = textCanvasRef.current;
    if (!ctx || !canvas) return null;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = 'white';

    // حساب حجم الخط بناءً على طول النص وعرض الشاشة
    let fontSize = 100;
    if (inputText.length > 15) {
      fontSize = 40;
    } else if (inputText.length > 10) {
      fontSize = 60;
    } else if (inputText.length > 8) {
      fontSize = 75;
    }
    
    // تقليل الحجم على الشاشات الصغيرة
    if (window.innerWidth < 480) {
      fontSize = Math.max(30, fontSize * 0.6);
    } else if (window.innerWidth < 768) {
      fontSize = Math.max(40, fontSize * 0.75);
    }
    
    ctx.font = `900 ${fontSize}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    ctx.fillText(inputText, canvas.width / 2, canvas.height / 2);

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
    const points: Array<{ x: number; y: number; z: number }> = [];

    // أخذ عينات أقل على الشاشات الصغيرة لتحسين الأداء
    const sampleStep = window.innerWidth < 480 ? 2 : 1;
    
    for (let y = 0; y < canvas.height; y += sampleStep) {
      for (let x = 0; x < canvas.width; x += sampleStep) {
        const alpha = imageData[(y * canvas.width + x) * 4 + 3];
        if (alpha > 150) {
          points.push({
            x: (x - canvas.width / 2) * 0.1,
            y: -(y - canvas.height / 2) * 0.1,
            z: (Math.random() - 0.5) * 1.5,
          });
        }
      }
    }
    return points;
  };

  const updateTargets = (inputText: string) => {
    const textPoints = sampleText(inputText);
    const isTextMode = textPoints !== null && textPoints.length > 0;

    if (particlesRef.current) {
      particlesRef.current.rotation.y = 0;
      particlesRef.current.rotation.x = 0;
      particlesRef.current.rotation.z = 0;
    }

    for (let i = 0; i < particleCountRef.current; i++) {
      if (isTextMode && textPoints) {
        const target = textPoints[i % textPoints.length];
        targetPositionsRef.current[i] = {
          x: target.x + (Math.random() - 0.5) * 0.1,
          y: target.y + (Math.random() - 0.5) * 0.1,
          z: target.z + (Math.random() - 0.5) * 0.1,
        };
      } else {
        const t = Math.acos(Math.random() * 2 - 1);
        const u = Math.random() * Math.PI * 2;
        const p = getHeartPoint(t, u);
        targetPositionsRef.current[i] = {
          x: p.x + (Math.random() - 0.5) * 0.4,
          y: p.y + (Math.random() - 0.5) * 0.4,
          z: p.z + (Math.random() - 0.5) * 0.4,
        };
      }
    }
  };

  const handleTextChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newText = e.target.value;
    setText(newText);
    updateTargets(newText);
  };

  return (
    <div className="fixed inset-0 w-screen h-screen overflow-hidden bg-black">
      <div ref={containerRef} className="absolute inset-0 w-full h-full" />

      <div className="fixed bottom-0 left-0 right-0 z-50 text-center p-4 sm:p-5 pb-[max(20px,env(safe-area-inset-bottom))] bg-gradient-to-t from-black/90 via-black/50 to-transparent flex justify-center items-center pointer-events-none">
        <input
          id="text-input"
          type="text"
          value={text}
          onChange={handleTextChange}
          maxLength={15}
          autoComplete="off"
          placeholder="اكتب نصاً..."
          className="pointer-events-auto w-full max-w-[500px] px-4 sm:px-5 py-2 sm:py-3 bg-white/5 border border-white/15 rounded-full text-white/70 text-sm sm:text-base outline-none backdrop-blur-[15px] transition-all duration-300 placeholder-white/40 focus:bg-white/10 focus:border-white/50 focus:text-white/90 focus:ring-2 focus:ring-white/20"
        />
      </div>
    </div>
  );
}
